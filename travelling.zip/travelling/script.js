// DOM Elements
const navbar = document.querySelector('.navbar');
const hamburger = document.querySelector('.hamburger');
const navMenu = document.querySelector('.nav-menu');
const navLinks = document.querySelectorAll('.nav-link');
const heroCards = document.querySelectorAll('.card');
const backgroundImages = document.querySelectorAll('.background-image');
const ctaButton = document.querySelector('.cta-button');
const darkModeToggle = document.getElementById('darkModeToggle');
const packageButtons = document.querySelectorAll('.package-button');
const carouselBtns = document.querySelectorAll('.carousel-btn');
const carouselSlide = document.querySelector('.carousel-slide');
const reviewSlides = document.querySelectorAll('.review-slide');
const reviewDots = document.querySelectorAll('.dot');
const reviewPrevBtn = document.querySelector('.review-prev');
const reviewNextBtn = document.querySelector('.review-next');
const contactForm = document.getElementById('contactForm');
const darkModeIcon = document.querySelector('#darkModeToggle i');

// Variables
let currentBackgroundIndex = 0;
let currentReviewIndex = 0;
let cardScrollInterval;
let autoScrollInterval;
let isDarkMode = false;

// Initialize the website
function init() {
    setupEventListeners();
    startHeroCardAutoScroll();
    startBackgroundAutoScroll();
    updateReviewSlide();
    checkDarkModePreference();
}

// Setup all event listeners
function setupEventListeners() {
    // Navbar hamburger menu toggle
    hamburger.addEventListener('click', toggleMobileMenu);
    
    // Close mobile menu when clicking a link
    navLinks.forEach(link => {
        link.addEventListener('click', closeMobileMenu);
    });
    
    // Hero card click events
    heroCards.forEach(card => {
        card.addEventListener('click', () => {
            const index = parseInt(card.getAttribute('data-index'));
            changeBackground(index);
            setActiveCard(index);
        });
    });
    
    // Dark mode toggle
    darkModeToggle.addEventListener('click', toggleDarkMode);
    
    // Package button click events
    packageButtons.forEach(button => {
        button.addEventListener('click', () => {
            alert('Booking functionality would be implemented here. In a real application, this would redirect to a booking page or open a booking modal.');
        });
    });
    
    // Destination carousel controls
    document.querySelector('.prev-btn').addEventListener('click', () => {
        moveCarousel('prev');
    });
    
    document.querySelector('.next-btn').addEventListener('click', () => {
        moveCarousel('next');
    });
    
    // Reviews carousel controls
    reviewPrevBtn.addEventListener('click', () => {
        currentReviewIndex = (currentReviewIndex - 1 + reviewSlides.length) % reviewSlides.length;
        updateReviewSlide();
    });
    
    reviewNextBtn.addEventListener('click', () => {
        currentReviewIndex = (currentReviewIndex + 1) % reviewSlides.length;
        updateReviewSlide();
    });
    
    // Review dots
    reviewDots.forEach(dot => {
        dot.addEventListener('click', () => {
            currentReviewIndex = parseInt(dot.getAttribute('data-slide'));
            updateReviewSlide();
        });
    });
    
    // Contact form submission
    contactForm.addEventListener('submit', handleContactSubmit);
    
    // Scroll event for navbar background
    window.addEventListener('scroll', handleScroll);
    
    // Parallax effect on scroll
    window.addEventListener('scroll', handleParallax);
}

// Toggle mobile menu
function toggleMobileMenu() {
    hamburger.classList.toggle('active');
    navMenu.classList.toggle('active');
}

// Close mobile menu
function closeMobileMenu() {
    hamburger.classList.remove('active');
    navMenu.classList.remove('active');
}

// Change hero background image
function changeBackground(index) {
    // Remove active class from all background images
    backgroundImages.forEach(img => {
        img.classList.remove('active');
    });
    
    // Add active class to selected background image
    backgroundImages[index].classList.add('active');
    
    // Update current index
    currentBackgroundIndex = index;
}

// Set active card in hero section
function setActiveCard(index) {
    // Remove active class from all cards
    heroCards.forEach(card => {
        card.classList.remove('active');
    });
    
    // Add active class to selected card
    heroCards[index].classList.add('active');
}

// Auto-scroll hero cards
function startHeroCardAutoScroll() {
    let cardIndex = 0;
    
    cardScrollInterval = setInterval(() => {
        // Remove active class from all cards
        heroCards.forEach(card => {
            card.classList.remove('active');
        });
        
        // Add active class to current card
        heroCards[cardIndex].classList.add('active');
        
        // Change background to match card
        changeBackground(cardIndex);
        
        // Increment card index
        cardIndex = (cardIndex + 1) % heroCards.length;
    }, 5000); // Change every 5 seconds
}

// Auto-scroll background images
function startBackgroundAutoScroll() {
    autoScrollInterval = setInterval(() => {
        currentBackgroundIndex = (currentBackgroundIndex + 1) % backgroundImages.length;
        changeBackground(currentBackgroundIndex);
        setActiveCard(currentBackgroundIndex);
    }, 7000); // Change every 7 seconds
}

// Move destination carousel
function moveCarousel(direction) {
    const carouselItems = document.querySelectorAll('.carousel-item');
    const itemWidth = carouselItems[0].offsetWidth;
    const visibleItems = Math.floor(document.querySelector('.carousel-container').offsetWidth / itemWidth);
    const totalItems = carouselItems.length;
    const maxTransform = (totalItems - visibleItems) * itemWidth;
    
    let currentTransform = parseInt(carouselSlide.style.transform?.replace('translateX(', '')?.replace('px)', '') || 0);
    
    if (direction === 'next') {
        currentTransform -= itemWidth * visibleItems;
        if (Math.abs(currentTransform) > maxTransform) {
            currentTransform = 0;
        }
    } else {
        currentTransform += itemWidth * visibleItems;
        if (currentTransform > 0) {
            currentTransform = -maxTransform;
        }
    }
    
    carouselSlide.style.transform = `translateX(${currentTransform}px)`;
}

// Update review slides
function updateReviewSlide() {
    // Remove active class from all slides
    reviewSlides.forEach(slide => {
        slide.classList.remove('active');
    });
    
    // Remove active class from all dots
    reviewDots.forEach(dot => {
        dot.classList.remove('active');
    });
    
    // Add active class to current slide and dot
    reviewSlides[currentReviewIndex].classList.add('active');
    reviewDots[currentReviewIndex].classList.add('active');
}

// Toggle dark mode
function toggleDarkMode() {
    isDarkMode = !isDarkMode;
    
    if (isDarkMode) {
        document.body.classList.add('dark-mode');
        darkModeIcon.classList.remove('fa-moon');
        darkModeIcon.classList.add('fa-sun');
        localStorage.setItem('darkMode', 'enabled');
    } else {
        document.body.classList.remove('dark-mode');
        darkModeIcon.classList.remove('fa-sun');
        darkModeIcon.classList.add('fa-moon');
        localStorage.setItem('darkMode', 'disabled');
    }
}

// Check dark mode preference
function checkDarkModePreference() {
    const savedDarkMode = localStorage.getItem('darkMode');
    
    if (savedDarkMode === 'enabled') {
        document.body.classList.add('dark-mode');
        darkModeIcon.classList.remove('fa-moon');
        darkModeIcon.classList.add('fa-sun');
        isDarkMode = true;
    }
}

// Handle scroll for navbar background
function handleScroll() {
    if (window.scrollY > 50) {
        navbar.style.backgroundColor = 'rgba(255, 255, 255, 0.98)';
        if (isDarkMode) {
            navbar.style.backgroundColor = 'rgba(30, 30, 30, 0.98)';
        }
        navbar.style.boxShadow = '0 5px 15px rgba(0, 0, 0, 0.1)';
    } else {
        navbar.style.backgroundColor = 'rgba(255, 255, 255, 0.95)';
        if (isDarkMode) {
            navbar.style.backgroundColor = 'rgba(30, 30, 30, 0.95)';
        }
        navbar.style.boxShadow = '0 2px 10px rgba(0, 0, 0, 0.1)';
    }
    
    // Update active nav link based on scroll position
    updateActiveNavLink();
}

// Update active nav link based on scroll position
function updateActiveNavLink() {
    const sections = document.querySelectorAll('section');
    const scrollPosition = window.scrollY + 100;
    
    sections.forEach(section => {
        const sectionTop = section.offsetTop;
        const sectionHeight = section.offsetHeight;
        const sectionId = section.getAttribute('id');
        
        if (scrollPosition >= sectionTop && scrollPosition < sectionTop + sectionHeight) {
            navLinks.forEach(link => {
                link.classList.remove('active');
                if (link.getAttribute('href') === `#${sectionId}`) {
                    link.classList.add('active');
                }
            });
        }
    });
}

// Handle parallax effect
function handleParallax() {
    const scrollPosition = window.scrollY;
    const hero = document.querySelector('.hero');
    
    if (scrollPosition < window.innerHeight) {
        const parallaxValue = scrollPosition * 0.5;
        hero.style.transform = `translateY(${parallaxValue}px)`;
    }
}

// Handle contact form submission
function handleContactSubmit(e) {
    e.preventDefault();
    
    // Get form elements
    const nameInput = document.getElementById('name');
    const emailInput = document.getElementById('email');
    const phoneInput = document.getElementById('phone');
    const interestSelect = document.getElementById('interest');
    const messageInput = document.getElementById('message');
    const formMessage = document.getElementById('formMessage');
    
    // Reset previous error messages
    clearErrorMessages();
    
    // Validate form
    let isValid = true;
    
    if (!nameInput.value.trim()) {
        showError(nameInput, 'Name is required');
        isValid = false;
    }
    
    if (!emailInput.value.trim()) {
        showError(emailInput, 'Email is required');
        isValid = false;
    } else if (!isValidEmail(emailInput.value)) {
        showError(emailInput, 'Please enter a valid email address');
        isValid = false;
    }
    
    if (phoneInput.value && !isValidPhone(phoneInput.value)) {
        showError(phoneInput, 'Please enter a valid phone number');
        isValid = false;
    }
    
    if (!interestSelect.value) {
        showError(interestSelect, 'Please select an interest');
        isValid = false;
    }
    
    if (!messageInput.value.trim()) {
        showError(messageInput, 'Message is required');
        isValid = false;
    }
    
    // If form is valid, simulate submission
    if (isValid) {
        // In a real application, you would send data to a server here
        formMessage.textContent = 'Thank you for your message! We will get back to you soon.';
        formMessage.className = 'form-message success';
        
        // Reset form
        contactForm.reset();
        
        // Clear message after 5 seconds
        setTimeout(() => {
            formMessage.textContent = '';
            formMessage.className = 'form-message';
        }, 5000);
    } else {
        formMessage.textContent = 'Please fix the errors above.';
        formMessage.className = 'form-message error';
    }
}

// Show error message for form field
function showError(input, message) {
    const formGroup = input.parentElement;
    const errorMessage = formGroup.querySelector('.error-message');
    errorMessage.textContent = message;
    input.style.borderColor = '#e53935';
}

// Clear all error messages
function clearErrorMessages() {
    const errorMessages = document.querySelectorAll('.error-message');
    const formInputs = document.querySelectorAll('.form-group input, .form-group select, .form-group textarea');
    
    errorMessages.forEach(message => {
        message.textContent = '';
    });
    
    formInputs.forEach(input => {
        input.style.borderColor = '';
    });
}

// Validate email format
function isValidEmail(email) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
}

// Validate phone number format
function isValidPhone(phone) {
    const phoneRegex = /^[\+]?[1-9][\d]{0,15}$/;
    return phoneRegex.test(phone.replace(/\D/g, ''));
}

// Lazy load images
function lazyLoadImages() {
    const imageObserver = new IntersectionObserver((entries, observer) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                const img = entry.target;
                const src = img.getAttribute('data-src');
                
                if (src) {
                    img.src = src;
                    img.removeAttribute('data-src');
                }
                
                observer.unobserve(img);
            }
        });
    });
    
    const images = document.querySelectorAll('img[data-src]');
    images.forEach(img => imageObserver.observe(img));
}

// Initialize the website when DOM is loaded
document.addEventListener('DOMContentLoaded', init);







const slides = document.querySelectorAll('.slide');
const heroBg = document.getElementById('heroBg');
const track = document.getElementById('sliderTrack');
const next = document.querySelector('.arrow.right');
const prev = document.querySelector('.arrow.left');

let index = 0;
const slideWidth = slides[0].offsetWidth + 15; // card + gap

function updateSlider() {
    // Active card
    slides.forEach(s => s.classList.remove('active'));
    slides[index].classList.add('active');

    // Background change
    heroBg.src = slides[index].dataset.bg;

    // ACTUAL SCROLL MOVE
    track.style.transform = `translateX(-${index * slideWidth}px)`;
}

// Initial
updateSlider();

// Auto scroll
setInterval(() => {
    index = (index + 1) % slides.length;
    updateSlider();
}, 4000);

// Arrow controls
next.addEventListener('click', () => {
    index++;
    if (index > slides.length - 1) index = 0;
    updateSlider();
});

prev.addEventListener('click', () => {
    index--;
    if (index < 0) index = slides.length - 1;
    updateSlider();
});

// Click card
slides.forEach((slide, i) => {
    slide.addEventListener('click', () => {
        index = i;
        updateSlider();
    });
});